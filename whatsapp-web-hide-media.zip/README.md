# WhatsApp Web Hide Media - Chrome extension

Chrome extension for WhatsApp Web. Hides media (images, videos and link previews) on WhatsApp Web. You just need to hover to see it.

[Download from the Chrome Web Store](https://chrome.google.com/webstore/detail/whatsapp-web-hide-media/bgbojloafcikdnigcnhabhemplfhgejn)

![Screenshot](/normal.png?raw=true)

---

### Credits

- ["Image" icon by unlimicon from the Noun Project](https://thenounproject.com/unlimicon/collection/image/?oq=image&cidx=1&i=568299)
- [OS X retina cursor with .sketch by Yanis Markin](https://dribbble.com/shots/2240077-OS-X-retina-cursor-with-sketch)
